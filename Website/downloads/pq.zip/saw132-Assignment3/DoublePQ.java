import java.util.ArrayList;
import java.util.PriorityQueue;
public class DoublePQ{
	PriorityQueue<Integer> pricePQ = new PriorityQueue<Integer>();
	PriorityQueue<Integer> mileagePQ = new PriorityQueue<Integer>();
	ArrayList<Integer> priceArray = new ArrayList<Integer>();		//gives you index of where it is
	ArrayList<Integer> mileageArray = new ArrayList<Integer>();		//gives you index of where it is
	ArrayList<myNode> myArray = new ArrayList<myNode>();	//important values of the car
	
	public DoublePQ(){}
	
	public void add(String myVIN, String myMake, String myModel, int myPrice, int myMileage, String myColor){
		myNode newNode = new myNode();
		newNode.create(myVIN, myMake, myModel, myPrice, myMileage, myColor);
		//.insert to add newNode to both stacks and arraylist
		priceArray.add(myPrice);
		mileageArray.add(myMileage);
		myArray.add(newNode);
		pricePQ.add(myPrice);
		mileagePQ.add(myMileage);
	}
	
	public void remove(String myVIN){
		//Find myVIN in myArray
		int i = 1;
		int myCheck = 0;
		while(i < myArray.size() && myCheck == 0){
			if(myArray.get(i-1).getVIN().equals(myVIN)){
				myCheck = i;
			}
			i++;
		}
		//Find price and mileage
		int myPrice = priceArray.get(i-1);
		int myMileage = mileageArray.get(i-1);
		//Remove the price from pricePQ and mileage from mileagePQ
		pricePQ.remove(myPrice);
		mileagePQ.remove(myMileage);
	}
	
	public void update(String myVIN, String myValue, int whatToUpdate){
		//Find myVIN in myArray
		int i = 0;
		int myCheck = 0;
		while(i < myArray.size() && myCheck == 0){
			if(myArray.get(i).getVIN().equals(myVIN)){
				myCheck = i;
			}
			i++;
		}
		//Change value in myArray
		//If needed, edit mileage or price (remove and then add)
		if(whatToUpdate == 1){
			//Update price
			int previousPrice = myArray.get(i-1).getPrice();
			myArray.get(i-1).editPrice(Integer.parseInt(myValue));
			priceArray.set(i-1,Integer.parseInt(myValue));
			pricePQ.remove(previousPrice);
			pricePQ.add(Integer.parseInt(myValue));
		}
		if(whatToUpdate == 2){
			//Update mileage
			int previousMileage = myArray.get(i-1).getMileage();
			myArray.get(i-1).editMileage(Integer.parseInt(myValue));
			mileageArray.set(i-1,Integer.parseInt(myValue));
			mileagePQ.remove(previousMileage);
			mileagePQ.add(Integer.parseInt(myValue));
		}
		else if(whatToUpdate == 3){
			//Update color
			myArray.get(i-1).editColor(myValue);
		}
	}
	
	public myNode findCar(int priceOrMileage){
		//Find lowest price or mileage from PQ
		if(pricePQ.size() == 0){
			myNode emptyNode = new myNode();
			return emptyNode;
		}
		
		int lowest = 0;
		if(priceOrMileage == 1){
			//Find lowest price
			lowest = pricePQ.peek();
			//Find coresponding VIN in arraylist
			lowest = priceArray.indexOf(lowest);
			return myArray.get(lowest);
		}
		else if(priceOrMileage == 2){
			//Find lowest mileage
			lowest = mileagePQ.peek();
			//Find coresponding VIN in arraylist
			lowest = mileageArray.indexOf(lowest);
			return myArray.get(lowest);
		}
		myNode emptyNode = new myNode();
		return emptyNode;
	}
	
	public myNode findCarMM(int priceOrMileage, String myMake, String myModel){
		int lowest;
		myNode tempNode;
		if(pricePQ.size() == 0){
			myNode emptyNode = new myNode();
			return emptyNode;
		}
		
		if(priceOrMileage == 1){
			//Remoove items from PQ until find right make/model
			ArrayList<Integer> tempArr = new ArrayList<Integer>();
			while(pricePQ.size() != 0){
				//Pull lowest value and remove from list
				lowest = pricePQ.poll();
				tempArr.add(lowest);
				//Go to arraylist
				lowest = priceArray.indexOf(lowest);
				tempNode = myArray.get(lowest);
				if(myMake.equals(tempNode.getMake()) && myModel.equals(tempNode.getModel())){
					//Fix the PQ
					for (Integer temp : tempArr) {
						pricePQ.add(temp);
					}
					return tempNode;
				}
			}
		}
		else if(priceOrMileage == 2){
			//Remoove items from PQ until find right make/model
			ArrayList<Integer> tempArr = new ArrayList<Integer>();
			while(mileagePQ.size() != 0){
				//Pull lowest value and remove from list
				lowest = mileagePQ.poll();
				tempArr.add(lowest);
				//Go to arraylist
				lowest = mileageArray.indexOf(lowest);
				tempNode = myArray.get(lowest);
				if(myMake.equals(tempNode.getMake()) && myModel.equals(tempNode.getModel())){
					//Fix the PQ
					for (Integer temp : tempArr) {
						mileagePQ.add(temp);
					}
					return tempNode;
				}
			}
		}
		myNode emptyNode = new myNode();
		return emptyNode;
	}
	
}