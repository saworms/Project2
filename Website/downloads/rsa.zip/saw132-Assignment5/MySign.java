import java.util.*;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.Path;

public class MySign {

    public static void main(String[] args) {
		//Takes two arguments
		char toDo = args[0].charAt(0);
		String numZeros = "";
		
		//If called s textfile
		if(toDo == 's'){
			//Generate SHA 256 hash of contents
			
			// lazily catch all exceptions...
			try {
				// read in the file to hash
				Path path = Paths.get(args[1]);
				byte[] data = Files.readAllBytes(path);
				
				// create class instance to create SHA-256 hash
				MessageDigest md = MessageDigest.getInstance("SHA-256");

				// process the file
				md.update(data);
				// generate a has of the file
				byte[] digest = md.digest();
				
				//Convert to BigInteger
				BigInteger myHash = new BigInteger(1, digest);
				
				//read file for D and N
				FileInputStream fis = new FileInputStream("privkey.rsa");
				BufferedReader br = new BufferedReader(new InputStreamReader(fis));
				String D = br.readLine();
				String N = br.readLine();
				br.close();
				
				//Decrypt hash value
				myHash = myHash.modPow(new BigInteger(D),new BigInteger(N));
				
				
				//Write an signed version of file that contains original contents and decrypted hash
				File file = new File(args[1]);
				FileInputStream fis1 = new FileInputStream(file);
				byte[] data1 = new byte[(int) file.length()];
				fis1.read(data1);
				fis1.close();

				String str = new String(data1, "UTF-8");
				
				
				Writer writer = null;
				try {
					writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(args[1]+".signed"), "utf-8"));
					
					writer.write(str+"\n");
					writer.write(myHash.toString()+"\n");
					writer.write("" + data.length);
				} catch (IOException ex) {
				  // report
				} finally {
				   try {writer.close();} catch (Exception ex) {/*ignore*/}
				}
			}
			catch(Exception e) {
				System.out.println(e.toString());
			}
		}
		else if(toDo == 'v'){
		//If called c textfile.txt.signed
			//Read contents of orginial file
			//Generate SHA 256 hash of contents
			//Read decrypted hash of file
			//encrypt this value w/ contents of pubkey.rsa
			//Compare the two hash values and print out wheter or not they are same
			String line;
			String last = "";
			String initHash = "";
			try {
				// FileReader reads text files in the default encoding.
				FileReader fileReader = new FileReader(args[1]);

				// Always wrap FileReader in BufferedReader.
				BufferedReader bufferedReader = new BufferedReader(fileReader);
				
				//get size of original stuff
				while ((line = bufferedReader.readLine()) != null) {
					initHash = last;
					last = line;
				}
				int hashSize = Integer.parseInt(last);
				
				// Always close files.
				bufferedReader.close(); 
				
				//Get the the data to hash
				Path path = Paths.get(args[1]);
				byte[] data = Files.readAllBytes(path);
				byte[] newdata = new byte[hashSize];
				
				//Cut out anything that was not part of the original hash
				for(int i = 0; i < hashSize; i++){
					newdata[i] = data[i];
				}
				
				//Hash the file
				try {
					
					//Hash the data
					// create class instance to create SHA-256 hash
					MessageDigest md = MessageDigest.getInstance("SHA-256");

					// process the file
					md.update(newdata);
					// generate a has of the file
					byte[] digest = md.digest();
					
					//Convert to BigInteger
					BigInteger myHash = new BigInteger(1, digest);
					BigInteger givenHash = new BigInteger(initHash);
					
					
					//read file for D and N
					FileInputStream fis = new FileInputStream("pubkey.rsa");
					BufferedReader br = new BufferedReader(new InputStreamReader(fis));
					String E = br.readLine();
					String N = br.readLine();
					br.close();
				
					//Decrypt hash value
					givenHash = givenHash.modPow(new BigInteger(E),new BigInteger(N));
					if(myHash.equals(givenHash))
						System.out.println("The signature is valid.");
					else
						System.out.println("The signature is not valid.");
					
					
					
					
				}
				catch(Exception e) {
					System.out.println(e.toString());
				}
				
				
				
				
				
			}
			catch(FileNotFoundException ex) {              
			}
			catch(IOException ex) {
			}
			
			
			
			
			
			
		}
	}
}