<h1>Contact Me</h1>

<p>If you want to get in touch with me, fill in the following form, and I will get back to you.

<form action="includes/Submit.php" method="post">
	<p>First Name : <input type="text" id="FirstName" name="FirstName"/>
	<br>Last Name : <input type="text" id="LastName" name="LastName"/>
	<br>Your Email : <input type="text" id="EmailAddress" name="EmailAddress"/>
	<br>Message&nbsp;&nbsp;&nbsp; : <input type="text" id="Message" name="Message">
	<br><br><input type="submit" id="submit" value="Submit" />
</form>
