import java.util.*;
import java.io.*;

public class Graph {
	ArrayList<ArrayList<myNode>> price = new ArrayList<ArrayList<myNode>>();
	ArrayList<ArrayList<myNode>> dist = new ArrayList<ArrayList<myNode>>();
	ArrayList<String> place = new ArrayList<String>();
	int totalSize = 0;
	public Graph(){}
	
	public void addLocation(String s){
		place.add(s);
		totalSize++;
	}
	
	public void updateGraph(int init, int fin, int mydist, int myprice){
		//Make the nodes
		init--;
		fin--;
		
		while(price.size() < init+1 || price.size() < fin+1)
			price.add(new ArrayList<myNode>());
		while(dist.size() < init+1 || dist.size() < fin+1)
			dist.add(new ArrayList<myNode>());
		
		myNode priceNode = new myNode();
		myNode distNode = new myNode();
		myNode priceNode2 = new myNode();
		myNode distNode2 = new myNode();
		priceNode.make(fin,myprice);
		distNode.make(fin,mydist);
		priceNode2.make(init,myprice);
		distNode2.make(init,mydist);
				
		//Update the arrays
		price.get(init).add(priceNode);
		dist.get(init).add(distNode);
		price.get(fin).add(priceNode2);
		dist.get(fin).add(distNode2);
		
		
	}
	
	public void printList(){
		System.out.println();
		System.out.println("Printing all paths:");
		for(int i = 0; i < place.size(); i++){
			System.out.println("Flights from " + place.get(i) + ":");
			for(int j = 0; j <price.get(i).size(); j++){
				System.out.println("\t" + place.get(price.get(i).get(j).getFin()) + ", " + dist.get(i).get(j).getWeight() + " miles, $" + price.get(i).get(j).getWeight() );
			}
			System.out.println();
		}
	}
	
	public void findMST(){
		//Prim
		
		System.out.println("\nMinimnm Spanning Tree\n");
		
		//Initialize array of just starting vertex
		//All others in not t
		int maxSize = 100000;
		int location = 0;
		int myJ = 0;
		int myI = 0;
		ArrayList<Integer> MST = new ArrayList<Integer>();
		ArrayList<Integer> other = new ArrayList<Integer>();
		ArrayList<myNode> temp = new ArrayList<myNode>();
		MST.add((Integer)0);
		for(int i = 1; i < place.size(); i++){
			other.add(new Integer(i));
		}
		
		//While there is not vectors in t
		while(!other.isEmpty()){
			//Find min edge in not t that connects it to t
			for(int i = 0; i < MST.size(); i++){
				temp = dist.get(MST.get(i));
				//Check all edges corresponding to t
				//If smallest and location is not in t, save
				for(int j = 0; j < temp.size(); j++){
					if(!MST.contains(temp.get(j).getFin()) && temp.get(j).getWeight() < maxSize){
						maxSize = temp.get(j).getWeight();
						location = temp.get(j).getFin();
						myI = MST.get(i);
					}
				}
			}
			
			//Add that edge and vertex to t
			//Remove from not t
			MST.add(new Integer(location));
			other.remove(new Integer(location));
			System.out.println(place.get(location) + " from " + place.get(myI) + " " + maxSize + " miles" );
			
			//Seperate trees
			if(maxSize == 100000){
				//Clear out first tree and take one from other to start next tree
				System.out.println("\nThere are places that cannot be reached from the starting location.  The next graph is:");
				
				MST.clear();
				MST.add(other.get(0));
				other.remove(0);
			}
			maxSize = 100000;
		
		}
		System.out.println();
		System.out.println();
	}
	
	public void shortDist(String city1, String city2){
		//Dijkstra
		int start = 0;
		int end = 0;
		for(int i = 0; i < place.size(); i++){
			if(city1.equals(place.get(i)))
				start = i;
			if(city2.equals(place.get(i)))
				end = i;
		}
		
		//Put into proper groups
		ArrayList<Integer> myLen = new ArrayList<Integer>();
		ArrayList<Integer> myPlace = new ArrayList<Integer>();
		ArrayList<Integer> myVisit = new ArrayList<Integer>();
		ArrayList<Integer> tempWeight = new ArrayList<Integer>();
		
		
		
		for(int i = 0; i < place.size(); i++)
			myPlace.add(new Integer(i));
		for(int i = 0; i < place.size(); i++)
			myLen.add(100000);
		for(int i = 0; i < place.size(); i++)
			tempWeight.add(100000);
		for(int i = 0; i < place.size(); i++)
			myVisit.add(0);
		
		myLen.set(start, 0);
		myVisit.set(start, 1);
		int tempVal = 100000;
		int cur = start;
		int tempSaved = 0;
		
		while(myVisit.get(end) == 0){
			
			//For each connected node to cur
			for(int i = 0; i < dist.get(cur).size(); i++){
				//Find if route is smaller
				tempVal = myLen.get(cur) + dist.get(cur).get(i).getWeight();
				if(tempVal < myLen.get(dist.get(cur).get(i).getFin())){
					myLen.set(dist.get(cur).get(i).getFin(), tempVal);
					tempWeight.set(dist.get(cur).get(i).getFin(), dist.get(cur).get(i).getWeight());
					myPlace.set(dist.get(cur).get(i).getFin(), cur);
				}
			}
			myVisit.set(cur,1);
			tempVal = 100000;
			int myCur = cur;
			for(int i = 0; i < myVisit.size(); i++){
				if(myLen.get(i) < tempVal && myVisit.get(i) == 0){
					tempVal = myVisit.get(i);
					cur = i;
				}
			}
			if (myCur == cur){
				System.out.println();
				System.out.println("They are not connected.");
				System.out.println();
				return;
			}
		}
		
		int tempPlace = end;
		int totalWeight = 0;
		System.out.println();
		System.out.println("In reverse order, the route to take is:");
		do{
			totalWeight = totalWeight + tempWeight.get(tempPlace);
			System.out.print(place.get(tempPlace) + " ");
			System.out.print(tempWeight.get(tempPlace) + " ");
			tempPlace = myPlace.get(tempPlace);
		}while(tempPlace != start);
		
		System.out.println(place.get(start) + " with a total weight of " + totalWeight);
		System.out.println();
		
	}
	
	public void shortPrice(String city1, String city2){
		//Dijkstra
		int start = 0;
		int end = 0;
		for(int i = 0; i < place.size(); i++){
			if(city1.equals(place.get(i)))
				start = i;
			if(city2.equals(place.get(i)))
				end = i;
		}
		
		//Put into proper groups
		ArrayList<Integer> myLen = new ArrayList<Integer>();
		ArrayList<Integer> myPlace = new ArrayList<Integer>();
		ArrayList<Integer> myVisit = new ArrayList<Integer>();
		ArrayList<Integer> tempWeight = new ArrayList<Integer>();
		
		
		
		for(int i = 0; i < place.size(); i++)
			myPlace.add(new Integer(i));
		for(int i = 0; i < place.size(); i++)
			myLen.add(100000);
		for(int i = 0; i < place.size(); i++)
			tempWeight.add(100000);
		for(int i = 0; i < place.size(); i++)
			myVisit.add(0);
		
		myLen.set(start, 0);
		myVisit.set(start, 1);
		int tempVal = 100000;
		int cur = start;
		int tempSaved = 0;
		
		while(myVisit.get(end) == 0){
			
			//For each connected node to cur
			for(int i = 0; i < price.get(cur).size(); i++){
				//Find if route is smaller
				tempVal = myLen.get(cur) + price.get(cur).get(i).getWeight();
				if(tempVal < myLen.get(price.get(cur).get(i).getFin())){
					myLen.set(price.get(cur).get(i).getFin(), tempVal);
					tempWeight.set(price.get(cur).get(i).getFin(), price.get(cur).get(i).getWeight());
					myPlace.set(price.get(cur).get(i).getFin(), cur);
				}
			}
			myVisit.set(cur,1);
			tempVal = 100000;
			int myCur = cur;
			for(int i = 0; i < myVisit.size(); i++){
				if(myLen.get(i) < tempVal && myVisit.get(i) == 0){
					tempVal = myVisit.get(i);
					cur = i;
				}
			}
			if (myCur == cur){
				System.out.println();
				System.out.println("They are not connected.");
				System.out.println();
				return;
			}
		}
		
		int tempPlace = end;
		int totalWeight = 0;
		System.out.println();
		System.out.println("In reverse order, the route to take is:");
		do{
			totalWeight = totalWeight + tempWeight.get(tempPlace);
			System.out.print(place.get(tempPlace) + " ");
			System.out.print(tempWeight.get(tempPlace) + " ");
			tempPlace = myPlace.get(tempPlace);
		}while(tempPlace != start);
		
		System.out.println(place.get(start) + " with a total weight of " + totalWeight);
		System.out.println();
		
	}
	
	public void shortHops(String city1, String city2){
		//Breadth first to find lesat amount of hops
		//Find first and last city
		int start = 0;
		int end = 0;
		for(int i = 0; i < place.size(); i++){
			if(city1.equals(place.get(i)))
				start = i;
			if(city2.equals(place.get(i)))
				end = i;
		}
		
		ArrayList<Integer> myVisit = new ArrayList<Integer>();
		for(int i = 0; i < place.size(); i++)
			myVisit.add(-1);
		
		//For each node, add all neighbors to queue
		//Pop head to be the next visited vertex
		//When get to end, stop
		
		LinkedList<Integer> myQueue = new LinkedList<Integer>();
		LinkedList<Integer> secQueue = new LinkedList<Integer>();
		int cur = start;
		myVisit.set(start, start);
		while(myVisit.get(end) == -1){
			for(int i = 0; i < price.get(cur).size(); i++){
				if(myVisit.get(price.get(cur).get(i).getFin()) == -1 && !myQueue.contains((Integer)price.get(cur).get(i).getFin())){
					myQueue.add((Integer)price.get(cur).get(i).getFin());
					secQueue.add((Integer)cur);
				}
			}
			
			if(myVisit.get(myQueue.peek()) == -1)
				myVisit.set(myQueue.peek(), secQueue.peek());
			
			
			if(myQueue.isEmpty()){
				System.out.println();
				System.out.println("These locations are not connected.");
				System.out.println();
				return;
			}
			
			cur = myQueue.poll();
			secQueue.poll();
		}
		
		int tempPlace = end;
		System.out.println();
		System.out.println("In reverse order, the route to take is:");
		do{
			System.out.print(place.get(tempPlace) + " ");
			tempPlace = myVisit.get(tempPlace);
		}while(tempPlace != start);
		
		System.out.println(place.get(start));
		System.out.println();
	}
	
	public void findCheap(int finalPrice){
		//Find all routes cheaper than X
		//cannot repeat a city
		ArrayList<myNode> visited = new ArrayList<myNode>();
		
		
		for(int i = 0; i < place.size(); i++){
			for(int j = 0; j < price.get(i).size(); j++){
				if(price.get(i).get(j).getWeight() < finalPrice){
					System.out.println(place.get(i) + " " + price.get(i).get(j).getWeight() + " " + place.get(price.get(i).get(j).getFin()));
					
					myNode tempNode = new myNode();
					tempNode.make(price.get(i).get(j).getFin(),price.get(i).get(j).getWeight());
					
					
					visited.add(tempNode);
					
					
					findCheapRecurse(i, finalPrice, visited);
					
					visited.remove(tempNode);
					System.out.println();
				}
			}
		}
	}
	
	private void findCheapRecurse(int start, int totalPrice, ArrayList<myNode> visited){
		System.out.println();
		int myPrice = 0;
		for(int i = 0; i < visited.size();i++)
			myPrice = myPrice + visited.get(i).getWeight();
		
		for(int i = 0; i < price.get(visited.get(visited.size()-1).getFin()).size(); i++){
			myPrice = myPrice + price.get(visited.get(visited.size()-1).getFin()).get(i).getWeight();
			if(myPrice < totalPrice){
				
				
				System.out.print(place.get(start));
				for(int j = 0; j < visited.size(); j++)
					System.out.print(" " + visited.get(j).getWeight() + " " + place.get(visited.get(j).getFin()));
				System.out.println(" " + price.get(visited.get(visited.size()-1).getFin()).get(i).getWeight() + " " + place.get(price.get(visited.get(visited.size()-1).getFin()).get(i).getFin()));
				
				
				
				myNode tempNode = new myNode();
				tempNode.make(price.get(visited.get(visited.size()-1).getFin()).get(i).getFin(),price.get(visited.get(visited.size()-1).getFin()).get(i).getWeight());
				
				
				visited.add(tempNode);
				
				
				findCheapRecurse(start, totalPrice, visited);
				
				
				visited.remove(tempNode);
				
				
			}
			
			
			myPrice = myPrice - price.get(visited.get(visited.size()-1).getFin()).get(i).getWeight();
		} 
		
		
	}
	
	public void addRoute(String city1, String city2, int mydist, int myprice){
		//Add to arrays
		//Find first and second cities
		//Use update graph
		int start = 0;
		int end = 0;
		for(int i = 0; i < place.size(); i++){
			if(city1.equals(place.get(i)))
				start = i+1;
			if(city2.equals(place.get(i)))
				end = i+1;
		}
		this.updateGraph(start,end,mydist,myprice);
	}
	
	public void removeRoute(String city1, String city2){
		//Delete from arrays
		//Find city 1 and city 2
		//Find path that connects them
		//Remove it
		//Remove the reverse path
		int start = 0;
		int end = 0;
		for(int i = 0; i < place.size(); i++){
			if(city1.equals(place.get(i)))
				start = i+1;
			if(city2.equals(place.get(i)))
				end = i+1;
		}
		start--;
		end--;
		ArrayList<myNode> tempPrice = price.get(start);
		for(int i = 0; i < price.get(start).size(); i++){
			if(tempPrice.get(i).getFin() == end)
				tempPrice.remove(i);
		}
		tempPrice = price.get(end);
		for(int i = 0; i < price.get(end).size(); i++){
			if(tempPrice.get(i).getFin() == start)
				tempPrice.remove(i);
		}
		ArrayList<myNode> tempDist = dist.get(start);
		for(int i = 0; i < dist.get(start).size(); i++){
			if(tempDist.get(i).getFin() == end)
				tempDist.remove(i);
		}
		tempDist = dist.get(end);
		for(int i = 0; i < dist.get(end).size(); i++){
			if(tempDist.get(i).getFin() == start)
				tempDist.remove(i);
		}
		
	}
	
	public void quit(String filename){
		//write back to file
		
		//Put total city size
		//Go through locations array
		//Go through other arrays to get all values
		try {
			File myFoo = new File(filename);
			FileWriter fooThing = new FileWriter(myFoo, false); // true to append
																 // false to overwrite.
			BufferedWriter fooWriter = new BufferedWriter(fooThing);
			fooWriter.write(totalSize + "");
			fooWriter.newLine();
			for(int i = 0; i < totalSize; i++){
				fooWriter.write(place.get(i));
				fooWriter.newLine();
			}
			
			for(int i = 0; i < price.size(); i++){
				for(int j = 0; j < price.get(i).size(); j++){
					if( i < price.get(i).get(j).getFin()){
						fooWriter.write((i+1) + " " + (price.get(i).get(j).getFin()+1) + " " + dist.get(i).get(j).getWeight() + " " + price.get(i).get(j).getWeight() + ".00" );
						fooWriter.newLine();
					}
				}
			}
			fooWriter.close();
		}
		 catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                filename + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + filename + "'");                  
            // Or we could just do this: 
            // ex.printStackTrace();
        }	
	}
	
}