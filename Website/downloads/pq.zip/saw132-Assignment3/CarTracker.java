//Select a car
//Double priority queue
//Store object according to relative priorities of two attributes
//Retrieve baised on minimum value of either attributes
//Retreive with lowest mileage or price
//Either lowest of all or of type

//Car class
	//VIN
	//Make
	//Model
	//Price
	//Mileage
	//Color
//Functions
	//Add car
	//Update car
	//Remove car
	//Retreieve lowest price
	//Retrieve lowest mileage
	//Retrieve lowest x by make and model

//Retrieve does not remvove car, just shows info
//Base around heaps with indirection data structures
//Need to be efficent

//Make documentation.txt to tell why I did what I did
import java.util.Scanner;
import java.util.ArrayList;
public class CarTracker {

    public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int i = 0;
		int j = 0;
		int k = 0;
		String myVIN = "";
		String myMake = "";
		String myModel = "";
		int myPrice = 0;
		int myMileage = 0;
		String myColor = "";
		DoublePQ myCars = new DoublePQ();
		
		
		do{
			System.out.println("What do you want to do? Enter the number corresponding with the option.\n(0) Exit program\n(1) Add a car\n(2) Update a car\n(3) Remove a car\n(4) Retrieve the car with the lowest price or mileage");
			i = scanner.nextInt();
			
			if(i == 1){
				System.out.println("What is the VIN?");
				myVIN = scanner.next();
				
				if(myVIN.length() != 17 || myVIN.contains("I") || myVIN.contains("O") || myVIN.contains("Q")){
					System.out.println("Error with VIN, cannot enter value.");
				}
				else{
					System.out.println("What is the car's make?");
					myMake = scanner.next();
					System.out.println("What is the car's model?");
					myModel = scanner.next();
					System.out.println("What is the price of the car (in dollars)?");
					myPrice = scanner.nextInt();
					System.out.println("What is the mileage of the car?");
					myMileage = scanner.nextInt();
					System.out.println("What is the color of the car?");
					myColor = scanner.next();
					
					myCars.add(myVIN, myMake, myModel, myPrice, myMileage, myColor);
					//Add new car with the values
					System.out.println("Successfully entered");
				}
			}
			else if(i == 2){
				System.out.println("What is the VIN of the car you want to update?");
				myVIN = scanner.next();
				if(myVIN.length() != 17 || myVIN.contains("I") || myVIN.contains("O") || myVIN.contains("Q")){
					System.out.println("Bad VIN");
				}
				else{
					System.out.println("What do you want to update about the car? Enter the number corresponding with the option.\n(1) The price of the car\n(2) The mileage of the car\n(3) The color of the car");
					j = scanner.nextInt();
					
					if(j == 1){
						System.out.println("What is the new price?");
						myPrice = scanner.nextInt();
						myCars.update(myVIN, Integer.toString(myPrice), j);
					}
					else if(j == 2){
						System.out.println("What is the new mileage?");
						myMileage = scanner.nextInt();
						myCars.update(myVIN, Integer.toString(myMileage), j);
					}
					else if(j == 3){
						System.out.println("What is the new color?");
						myColor = scanner.next();
						myCars.update(myVIN, myColor, j);
					}
					System.out.println("Updated.");
					}
			}
			else if(i == 3){
				System.out.println("What is the VIN of the car you want to remove?");
				myVIN = scanner.next();
				
				if(myVIN.length() != 17 || myVIN.contains("I") || myVIN.contains("O") || myVIN.contains("Q")){
					System.out.println("Bad VIN");
				}
				else{
					//Remove the car
					myCars.remove(myVIN);
					System.out.println("Removed.");
					
				}
				
				
				
			}
			else if(i == 4){
				System.out.println("What information do you want to get? Enter the number corresponding with the option.\n(1) Lowest price of a car\n(2) Lowest mileage of a car");
				j = scanner.nextInt();
				System.out.println("Do you want a specific make and model? Enter the number corresponding with the option.\n(1) Yes\n(2) No");
				k = scanner.nextInt();
				myNode thisNode = new myNode();
				if(k == 1){
					System.out.println("Please insert the make of the car.");
					myMake = scanner.next();
					
					System.out.println("Please insert the model of the car.");
					myModel = scanner.next();
					
					if(j == 1){
						//Search using price
						thisNode = myCars.findCarMM(j, myMake, myModel);
					}
					else if(j == 2){
						//Search using mileage
						thisNode = myCars.findCarMM(j, myMake, myModel);
					}
					
					thisNode.printNode();
				}
				else if(k == 2){
					if(j == 1){
						//Search using price
						thisNode = myCars.findCar(j);
					}
					else if(j == 2){
						//Search using mileage
						thisNode = myCars.findCar(j);
					}
					
					thisNode.printNode();
				}
			}
			else if(i != 0){
				System.out.println("Incorrect value, please enter 0 - 4.");
			}
			System.out.println("\nDone, what do you want to do next?\n");
		}while(i != 0);
    }
}
