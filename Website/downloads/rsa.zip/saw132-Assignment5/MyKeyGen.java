import java.util.*;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.io.*;

public class MyKeyGen {

    public static void main(String[] args) {
		//Generate keypair
		Random rnd = new Random();
		
		//Pick P and Q to be random primes of an appropriate size
		BigInteger myP;
		myP = BigInteger.probablePrime(512,rnd);
		BigInteger myQ;
		myQ = BigInteger.probablePrime(512,rnd);
		
		//Make N = P*Q
		BigInteger myN;
		myN = myP.multiply(myQ);
		
		//Make PHI(N) = (P-1)*(Q-1)
		BigInteger myPhiN;
		myPhiN = myP.subtract(BigInteger.ONE).multiply(myQ.subtract(BigInteger.ONE));
		
		//Pick E such that 1<E<PHI(N) and GCD(E,PHI(N))=1 (E must not divide PHI(N) evenly
		BigInteger myE;
		myE = new BigInteger("65537");
		while(myE.min(myPhiN).equals(myE) && !BigInteger.ONE.equals(myE.gcd(myPhiN))){
			myE = myE.add(BigInteger.ONE.add(BigInteger.ONE));
		}
		
		//Pick D such that D = E^-1 mod PHI(N)
		BigInteger myD;
		myD = myE.modInverse(myPhiN);
		
		
		//After generating, save E and N to pubkey.rsa and D and N to privkey.rsa
		Writer writer = null;
		Writer writer2 = null;
		try {
			writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("pubkey.rsa"), "utf-8"));
			writer.write(myE.toString() + "\n");
			writer.write(myN.toString());
		} catch (IOException ex) {
		  // report
		} finally {
		   try {writer.close();} catch (Exception ex) {/*ignore*/}
		}
		
		try {
			writer2 = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("privkey.rsa"), "utf-8"));
			writer2.write(myD.toString() + "\n");
			writer2.write(myN.toString());
		} catch (IOException ex) {
		  // report
		} finally {
		   try {writer2.close();} catch (Exception ex) {/*ignore*/}
		}
		
	}
}