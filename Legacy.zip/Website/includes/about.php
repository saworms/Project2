<h1>About Me</h1>
<br>
<div class="left">
	<img src="Spencer.jpg" alt="Spencer Worms" width= 200px >

</div>

<div class = "right">
	
	<p>My name is Spencer Worms and I am currently a Junior in the Univeristy of Pittsburgh going for a degree in Computer Engineering.<br><br>
	<p>If you want to contact me, you can fill out the <a href='#contact'>form at the bottom of the page</a> or email me at saworms@comcast.net.<br><br>
	<p>Currently, I am have a cumulative GPA of 3.137, with 86 total credits taken.<br><br>
	<p>I am an Eagle Scout, with my Eagle project being me leading a group of scouts in helping restore a local church.<br><br>
	<p>I have participated in the FIRST Robotics competition for 4 years during High School.<br><br>
	<p><a href="downloads/resume.docx" download>Resume (old)</a><br><br>
	
	
</div>
