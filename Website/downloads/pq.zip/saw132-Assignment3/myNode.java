public class myNode{
	String myVIN;
	String myMake;
	String myModel;
	int myPrice;
	int myMileage;
	String myColor;
	
	public void myNode(){}
	
	public void create(String newVIN, String newMake, String newModel, int newPrice, int newMileage, String newColor){
		myVIN = newVIN;
		myMake = newMake;
		myModel = newModel;
		myPrice = newPrice;
		myMileage = newMileage;
		myColor = newColor;
	}
	
	public String getVIN(){
		return myVIN;
	}
	
	public int getPrice(){
		return myPrice;
	}
	
	public int getMileage(){
		return myMileage;
	}
	
	public String getMake(){
		return myMake;
	}
	
	public String getModel(){
		return myModel;
	}
	
	public void editPrice(int newPrice){
		myPrice = newPrice;
	}
	
	public void editMileage(int newMileage){
		myMileage = newMileage;
	}
	
	public void editColor(String newColor){
		myColor = newColor;
	}
	
	public void printNode(){
		if(myVIN == null)
			System.out.println("There are no cars to show");
		else{
			System.out.println("The VIN of the car is " + myVIN + ".");
			System.out.println("The make of the car is " + myMake + ".");
			System.out.println("The model of the car is " + myModel + ".");
			System.out.println("The price of the car is $" + myPrice + ".");
			System.out.println("The mileage of the car is " + myMileage + " miles.");
			System.out.println("The color of the car is " + myColor + ".");
		}
		
	}
	
	/*public Key getKey(){
		return myKey();
	}*/
	
}