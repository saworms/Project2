public class myNode{
	int endLocation;
	int weight;
	
	public void myNode(){}
	
	public void make(int goTo, int myWeight){
		endLocation = goTo;
		weight = myWeight;
	}
	
	public void create(int goTo){
		endLocation = goTo;
	}
	
	public void update(int myWeight){
		weight = myWeight;
	}
	
	public int getFin(){
		return endLocation;
	}
	
	public int getWeight(){
		return weight;
	}
	
}