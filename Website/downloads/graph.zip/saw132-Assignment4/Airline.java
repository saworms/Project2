import java.io.*;
import java.util.*;

public class Airline {

    public static void main(String[] args) {
        
		//Get file to read in
		
		String fileName = "";
		String line;
		int numCities = 0;
		int i = 0;
		ArrayList<String> myArr = new ArrayList<String>();
		Scanner scanner = new Scanner(System.in);
		Graph myGraph = new Graph(); 
		
		
		System.out.println("Please enter a file name:");
		fileName = scanner.next();
		
		//Read from file
		try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = new FileReader(fileName);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = new BufferedReader(fileReader);
			
			line = bufferedReader.readLine();
			numCities = Integer.parseInt(line);
			
            while((line = bufferedReader.readLine()) != null) {
				if(i < numCities){
					myGraph.addLocation(line);
					i++;
				}
				else{
					int init = Integer.parseInt(line.substring(0,line.indexOf(" ")));
					line = line.substring(line.indexOf(" ")+1);
					int fin = Integer.parseInt(line.substring(0,line.indexOf(" ")));
					line = line.substring(line.indexOf(" ")+1);
					int mydist = Integer.parseInt(line.substring(0,line.indexOf(" ")));
					line = line.substring(line.indexOf(" ")+1);
					int myprice = Integer.parseInt(line.substring(0,line.indexOf(".")));
					myGraph.updateGraph(init,fin,mydist,myprice);
				}
				
            }   

            // Always close files.
            bufferedReader.close(); 
			
			do{
				System.out.println();
				System.out.println("What do you want to do? Please enter the corresponding number to the option.");
				System.out.println("(0)Exit");
				System.out.println("(1)Show all direct routes");
				System.out.println("(2)Print minimum spanning tree");
				System.out.println("(3)Find shortest path using miles");
				System.out.println("(4)Find shortest path using price");
				System.out.println("(5)Find shortest path based on number of hops");
				System.out.println("(6)Print all trips costing less than a certain dollar amount");
				System.out.println("(7)Add a new route");
				System.out.println("(8)Delete a route");
				i = scanner.nextInt();
				
				//Get input and go to appropreate function
				if(i == 1)
					myGraph.printList();
				else if(i == 2)
					myGraph.findMST();
				else if(i == 3){
					System.out.println("Please enter the cities you want to go to one at a time.");
					myGraph.shortDist(scanner.next(), scanner.next());
				}
				else if(i == 4){
					System.out.println("Please enter the cities you want to go to one at a time.");
					myGraph.shortPrice(scanner.next(), scanner.next());
				}
				else if(i == 5){
					System.out.println("Please enter the cities you want to go to one at a time.");
					myGraph.shortHops(scanner.next(), scanner.next());
				}
				else if(i == 6){
					System.out.println("Please enter a price.");
					myGraph.findCheap(scanner.nextInt());
				}
				else if(i == 7){
					System.out.println("Please enter new route.");
					System.out.println("Please enter the starting city.");
					String first = scanner.next();
					System.out.println("Please enter the destination city.");
					String sec = scanner.next();
					System.out.println("Please enter the cost.");
					int cost = scanner.nextInt();
					System.out.println("Please enter the distance.");
					int dist = scanner.nextInt();
					myGraph.addRoute(first,sec,dist,cost);
				}
				else if(i == 8){
					System.out.println("Please enter the deleted route.");
					System.out.println("Please enter the starting city.");
					String first = scanner.next();
					System.out.println("Please enter the destination city.");
					String sec = scanner.next();
					myGraph.removeRoute(first,sec);
				}
				
			}while(i != 0);
			
			myGraph.quit(fileName);
			System.out.println();
			System.out.println("Exiting program");
			System.out.println();
			
			
			
			
			
			
			
			
			
			

        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'");                  
            // Or we could just do this: 
            // ex.printStackTrace();
        }	
    }
}